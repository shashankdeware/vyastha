// Shared helpers for the verified contact desk (Vercel serverless functions).
const crypto = require('crypto');
const SECRET = () => process.env.CONTACT_SECRET || '';
const b64 = (o) => Buffer.from(JSON.stringify(o)).toString('base64url');
const hmac = (s) => crypto.createHmac('sha256', SECRET()).update(s).digest('base64url');
const codeHash = (code, id) => crypto.createHash('sha256').update(code + ':' + id + ':' + SECRET()).digest('hex');
const sign = (p) => { const b = b64(p); return b + '.' + hmac(b); };
const open = (t) => {
  const [b, s] = String(t || '').split('.');
  if (!b || !s) return null;
  const good = hmac(b);
  if (s.length !== good.length || !crypto.timingSafeEqual(Buffer.from(s), Buffer.from(good))) return null;
  try { return JSON.parse(Buffer.from(b, 'base64url').toString()); } catch { return null; }
};
// best-effort limiter (per warm serverless instance)
const hits = new Map();
const limited = (key, max, ms) => {
  const now = Date.now(), a = (hits.get(key) || []).filter((t) => now - t < ms);
  a.push(now); hits.set(key, a);
  return a.length > max;
};
const ip = (req) => String((req.headers['x-forwarded-for'] || '').split(',')[0] || req.socket?.remoteAddress || 'x').trim();
const configured = () => SECRET() && process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASSWORD && process.env.SMTP_FROM_EMAIL;
async function mail({ to, subject, text, replyTo }) {
  const nodemailer = require('nodemailer');
  const port = Number(process.env.SMTP_PORT || 587);
  const t = nodemailer.createTransport({
    host: process.env.SMTP_HOST, port,
    secure: String(process.env.SMTP_USE_SSL || '').toLowerCase() === 'true' || port === 465,
    auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASSWORD },
  });
  await t.sendMail({ from: `"${process.env.SMTP_FROM_NAME || 'Vyastha'}" <${process.env.SMTP_FROM_EMAIL}>`, to, subject, text, replyTo });
}
const send = (res, code, body) => { res.statusCode = code; res.setHeader('Content-Type', 'application/json'); res.end(JSON.stringify(body)); };
module.exports = { sign, open, codeHash, limited, ip, configured, mail, send, crypto };
